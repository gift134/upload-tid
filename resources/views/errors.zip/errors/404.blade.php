<html>
<header>
<title>Error 404</title>

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

<link href="/resources/assets/front_assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/resources/assets/front_assets/vendor/icofont/icofont.min.css" rel="stylesheet">
<link href="/resources/assets/front_assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet"> 
<link href="/resources/assets/front_assets/vendor/font-awesome/css/font-awesome.css" rel="stylesheet"> 
<link href="/resources/assets/front_assets/vendor/venobox/venobox.css" rel="stylesheet">

<link href="/resources/assets/front_assets/css/style.css" rel="stylesheet">
</header>
<body>
<h2 style="text-align:center; font-size:75px; padding:20px; padding-top:100px;padding-bottom:50px;color: #787878;">Something went wrong!</h2><footer  style="border-top:1px solid grey; padding:50px 0;">

  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-lg-4 col-md-6 footer-links">
          <h4>Home Alarm Security</h4>
          <ul class="fa-ul">
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span></i> <a href="/adt-home-security">ADT</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/brinks-home-security">Brinks</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/vivint-home-security">Vivint</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/ring-home-security">Ring</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/simplisafe-home-security">SimpliSafe</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-6 footer-links">
          <h4>Packages</h4>
          <ul class="fa-ul">
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/adt-home-security#feature">ADT</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span></i> <a href="/brinks-home-security#package">Brinks</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/vivint-home-security#package-pricing">Vivint</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/ring-home-security#package-pricing">Ring</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/simplisafe-home-security#feature">SimpliSafe</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-6 footer-links">
          <h4>Quotes</h4>
          <ul class="fa-ul">
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/adt-home-security#contact">ADT</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/brinks-home-security#contact">Brinks</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/vivint-home-security#contact">Vivint</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/ring-home-security#contact">Ring</a></li>
            <li><span class="fa-li"><i class="fas fa-chevron-right"></i></span> <a href="/simplisafe-home-security#contact">SimpliSafe</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div> 
  
<div class="container py-4">
    <div class="copyright" style="text-align:center">
        <p><a href="/term-and-condition">Term and Condition</a> | <a href="/privacy-policy">Privacy Policy</a> | <a href="/disclaimer">Disclaimer</a></p>
        <label><strong><span>HomeAlarmSecurity.org</span></strong> has conducted impartial research to recommend products. This is not a guarantee. Each individual’s unique needs should be considered when deciding on chosen products.</label>
      &copy; Copyright <strong><span>HomeAlarmSecurity.org</span></strong>. All Rights Reserved
    </div>
</div>
</footer>

<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
</body>
<!-- Vendor JS Files -->
<script src="/resources/assets/front_assets/vendor/jquery/jquery.min.js"></script>
<script src="/resources/assets/front_assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/resources/assets/front_assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="/resources/assets/front_assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="/resources/assets/front_assets/vendor/venobox/venobox.min.js"></script>


<!-- Template Main JS File -->
<script src="/resources/assets/front_assets/js/main.js"></script>

<script src="https://kit.fontawesome.com/c5b4d19451.js" crossorigin="anonymous"></script>

</html>